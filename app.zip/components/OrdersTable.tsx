"use client";

import { useState } from "react";
import { Table, Button, Select, Modal } from "antd";
import TagModal from "./TagModal";

import {
  EditOutlined,
  DeleteOutlined,
  ShareAltOutlined,
} from "@ant-design/icons";

const data = [
  {
    key: "1",
    user: "Soji Abraham",
    court: "Court Complex, Kunnamkulam",
    district: "Thrissur",
    product: "Judgement #584854",
    price: "₹3,500",
    status: "Cancelled",
    days: "",
  },
  {
    key: "2",
    user: "Shaman",
    court: "District Court Thrissur",
    district: "Thrissur",
    product: "Interim Order #487565",
    price: "₹150",
    status: "Order Placed",
    days: "03 days since payment",
  },
  {
    key: "3",
    user: "Gopalan",
    court: "District Court Thrissur",
    district: "Thrissur",
    product: "Other #2500",
    price: "₹2,500",
    status: "Payment Completed",
    days: "11 days since payment",
  },
];

export default function OrdersTable() {
  const [detailsOpen, setDetailsOpen] = useState(false);
const [tagModalOpen, setTagModalOpen] = useState(false);

  const columns = [
    {
      title: "#",
      width: 50,
      render: (_: any, __: any, index: number) =>
        index + 1,
    },

    {
      title: "USER INFO",
      width: 240,

      render: (record: any) => (
        <div>
          <div
            style={{
              fontWeight: 600,
              marginBottom: 4,
            }}
          >
            {record.user}
          </div>

          <div style={{ color: "#666" }}>
            +91 80861 65790
          </div>

          <div style={{ color: "#666" }}>
            OP/000251/2026
          </div>

          <Button
            size="small"
            className="copy-btn"
            style={{ marginTop: 10 }}
          >
            Copy Address
          </Button>
        </div>
      ),
    },

    {
      title: "COURT COMPLEX",
      width: 200,

      render: (record: any) => (
        <>
          <div
            style={{
              fontWeight: 600,
            }}
          >
            {record.court}
          </div>

          <div
            style={{
              color: "#888",
              marginTop: 4,
            }}
          >
            {record.district}
          </div>
        </>
      ),
    },

    {
      title: "PRODUCTS",
      width: 180,

      render: (record: any) => (
        <>
          <div
            style={{
              fontWeight: 600,
            }}
          >
            {record.product}
          </div>

          <div
            style={{
              color: "#666",
              marginTop: 4,
            }}
          >
            {record.price}
          </div>
        </>
      ),
    },

    {
      title: "ORDER DATE",
      width: 140,

      render: () => (
        <>
          <div>7 Feb 2026</div>

          <div
            style={{
              color: "#888",
              fontSize: 12,
            }}
          >
            12:57 PM
          </div>
        </>
      ),
    },

    {
      title: "STATUS",
      width: 250,

      render: (record: any) => (
        <>
          <Select
            defaultValue="Update Status"
            style={{
              width: 170,
            }}
            options={[
              {
                value: "placed",
                label: "Order Placed",
              },
              {
                value: "cancelled",
                label: "Cancelled",
              },
              {
                value: "completed",
                label: "Payment Completed",
              },
            ]}
          />

          <div style={{ marginTop: 10 }}>
            <span
              className={
                record.status === "Cancelled"
                  ? "status-cancelled"
                  : record.status ===
                    "Payment Completed"
                  ? "status-completed"
                  : "status-placed"
              }
            >
              {record.status}
            </span>
          </div>

          {record.days && (
            <div
              style={{
                color: "#FF6A00",
                marginTop: 8,
                fontSize: 12,
                fontWeight: 500,
              }}
            >
              {record.days}
            </div>
          )}
        </>
      ),
    },

    {
      title: "ORDER DETAILS / E-SIGN",
      width: 220,

      render: () => (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 10,
          }}
        >
          <Button
            className="action-btn"
            onClick={() =>
              setDetailsOpen(true)
            }
          >
            View
          </Button>

          <Button className="action-btn">
            E-sign
          </Button>
        </div>
      ),
    },

    {
      title: "TAGS / NOTE",
      width: 280,

      render: () => (
  <div>
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        marginBottom: 10,
      }}
    >
      <Select
        placeholder="Choose Tag"
        style={{ width: 120 }}
      />

      <Button
        icon={<EditOutlined />}
        size="small"
        onClick={() => setTagModalOpen(true)}
      />
    </div>

    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: 6,
      }}
    >
      <span className="tag tag-blue">
        Subscription Pending
      </span>

      <span className="tag tag-brown">
        Add Case
      </span>

      <span className="tag tag-yellow">
        Aadhaar Verified
      </span>

      <span className="tag tag-green">
        Gouri
      </span>
    </div>
  </div>
),
    },

    {
      title: "CLERK",
      width: 220,

      render: () => (
        <>
          <div
            style={{
              fontWeight: 600,
              marginBottom: 8,
            }}
          >
            Shabarinath
          </div>

          <div
            style={{
              display: "flex",
              gap: 16,
              marginBottom: 10,
            }}
          >
            <EditOutlined />
            <DeleteOutlined />
            <ShareAltOutlined />
          </div>

          <Button
            size="small"
            className="assign-btn"
          >
            Assign
          </Button>
        </>
      ),
    },
  ];

  return (
    <>
      <div
        style={{
          width: "calc(100vw - 170px)",
          background: "#fff",
          borderRadius: 16,
          border: "1px solid #E5E5E5",
          overflow: "hidden",
          marginTop: 20,
        }}
      >
        <Table
          rowClassName={() => "custom-row"}
          columns={columns}
          dataSource={data}
          pagination={{
            pageSize: 3,
            showSizeChanger: false,
          }}
          scroll={{
            x: 1600,
          }}
        />
      </div>

      <Modal
        title="Order Details"
        open={detailsOpen}
        footer={null}
        onCancel={() =>
          setDetailsOpen(false)
        }
        width={700}
      >
        <p>
          <b>Applicant:</b> Laisamma George
        </p>

        <p>
          <b>Case Number:</b> WA 233/2024
        </p>

        <p>
          <b>Case Name:</b> Laisamma George & Others
        </p>

        <p>
          <b>Court:</b> JFCM 1 District Court Thrissur
        </p>

        <p>
          <b>Document Type:</b> Certified True Copy -
          Judgment
        </p>
        
      </Modal>
      <TagModal
  open={tagModalOpen}
  onClose={() => setTagModalOpen(false)}
/>
    </>
  );
}