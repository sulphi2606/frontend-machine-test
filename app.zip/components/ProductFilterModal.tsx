"use client";

import { Modal, Checkbox, Button } from "antd";
import { useState } from "react";

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function ProductFilterModal({
  open,
  onClose,
}: Props) {
  const [selectedProducts,
    setSelectedProducts] =
    useState<string[]>([
      "Judgement",
    ]);

  const products = [
    "All",
    "Judgement",
    "Interim Order",
    "Other",
  ];

  const toggleProduct = (
    product: string
  ) => {
    if (
      selectedProducts.includes(
        product
      )
    ) {
      setSelectedProducts(
        selectedProducts.filter(
          (p) =>
            p !== product
        )
      );
    } else {
      setSelectedProducts([
        ...selectedProducts,
        product,
      ]);
    }
  };

  return (
    <Modal
      title="Product Filter"
      open={open}
      onCancel={onClose}
      footer={null}
      width={340}
      centered
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 16,
        }}
      >
        {products.map(
          (product) => (
            <Checkbox
              key={product}
              checked={selectedProducts.includes(
                product
              )}
              onChange={() =>
                toggleProduct(
                  product
                )
              }
            >
              {product}
            </Checkbox>
          )
        )}
      </div>

      <div
        style={{
          display: "flex",
          justifyContent:
            "flex-end",
          gap: 10,
          marginTop: 30,
        }}
      >
        <Button
          style={{
            borderRadius: 20,
            color: "#5B1F46",
            borderColor:
              "#5B1F46",
          }}
        >
          Reset Filter
        </Button>

        <Button
          type="primary"
          style={{
            borderRadius: 20,
            background:
              "#5B1F46",
            borderColor:
              "#5B1F46",
          }}
        >
          Apply
        </Button>
      </div>
    </Modal>
  );
}